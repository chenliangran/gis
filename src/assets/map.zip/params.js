const Param = {
    fps  : 10,
    path : {
        mode : 'default',//路径模式
        len  : 400 
    }
}

export default Param