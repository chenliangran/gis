<template>
    <div class="foot">
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
    .foot {
        width: 100%;
        position: fixed;
        bottom: 0;
        background: url("../../../static/img/foot.png");
        z-index: 10;
        height: 40px;
    }
</style>
